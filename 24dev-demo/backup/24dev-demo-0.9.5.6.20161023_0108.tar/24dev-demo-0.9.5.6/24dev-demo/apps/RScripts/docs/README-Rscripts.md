# RScripts Usage
* Various R scripts to demonstrate batch R sripting techniques.
* Command Line Usage: ./<scriptName.r>
* Please view the license file under the 24dev-demo folder. 
