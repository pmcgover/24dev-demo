# r4st Plant Database 
* A plant database system featuring csv file import/export.  See details at: http://tinyurl.com/dbr4st
* Usage: Execute $APPS/r4st/bin/r4st-wrapper.sh
* The r4st-wrapper.sh program performs system setup and runs/verifies r4st-loader.sh.
* You can browse the r4st production database system at: http://localhost/r4stdb/dbkiss.php
