# 24dev-demo-0.9.5.6 Project Summary 
Welcome to Patrick McGovern's 24dev-demo-0.9.5.6 Software Digital Portfolio. Created on Sun Oct 23 01:06:49 UTC 2016 with the following details:
* Total number of applications: 5
* Total regression test run time in seconds: 5 
* Total regression test runs: 6  
* Number of regression test checks: 4
* Success! - All regression tests PASSED!

Regression Test Nbr|Application Name|Test Name|Run Time Seconds|Pass or Fail
 --- | --- | --- | --- | --- 
1|RScripts|HelloWorld|1|Pass
2|RScripts|top10-2014-clones-AngledXaxis|0|Pass
3|RScripts|top10-2014-clones-StraightXaxis|0|Pass
4|competitionIndexer|u07m-6yrStacks-Input|1|Pass
5|r4st|r4st-loader|3|Pass
