# 24dev-demo-0.9.5.7 Project Summary 
Welcome to Patrick McGovern's 24dev-demo-0.9.5.7 Software Digital Portfolio. Created on Mon Oct 24 01:37:15 UTC 2016 with the following details:
* Total number of applications: 5
* Total regression test run time in seconds: 5 
* Total regression test runs: 6  
* Number of regression test checks: 5
* Total Project Lines Of Code: 763
* Success! - All regression tests PASSED!

Regression Test Nbr|Application Name|Test Name|Run Time Seconds|App Lines Of Code|Pass or Fail
 --- | --- | --- | --- | --- | --- 
1|RScripts|HelloWorld|0|71|Pass
2|RScripts|top10-2014-clones-AngledXaxis|0|71|Pass
3|RScripts|top10-2014-clones-StraightXaxis|0|71|Pass
4|competitionIndexer|u07m-6yrStacks-Input|1|371|Pass
5|r4st|r4st-loader|3|179|Pass
