# 24dev-demo-0.9.5.9 Project Summary 
Welcome to Patrick McGovern's 24dev-demo-0.9.5.9 Software Digital Portfolio. Created on Sun Oct 30 00:21:17 UTC 2016 with the following details:
* Total number of applications: 5
* Total regression test run time in seconds: 5 
* Total regression test runs: 6  
* Number of regression test checks: 5
* Total Project Lines Of Code: 1749
* Success! - All regression tests PASSED!

Regression Test Nbr|Application Name|Test Name|Run Time Seconds|App Lines Of Code|Pass or Fail
 --- | --- | --- | --- | --- | --- 
1|r4st|r4st-loader|3|900|Pass
2|competitionIndexer|u07m-6yrStacks-Input|1|371|Pass
3|RScripts|HelloWorld|1|71|Pass
4|RScripts|top10-2014-clones-AngledXaxis|0|71|Pass
5|RScripts|top10-2014-clones-StraightXaxis|0|71|Pass
