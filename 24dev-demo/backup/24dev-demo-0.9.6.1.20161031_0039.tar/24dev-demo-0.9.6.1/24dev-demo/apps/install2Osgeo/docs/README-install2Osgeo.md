# install2Osgeo Documentation 
* A repeatable 24dev-demo installation process that installs user/application profiles, purges log files and creates backups.
* Usage: Execute $APPS/install2Osgeo/bin/install2Osgeo.sh
* Users can re-run the install script to update profile changes, and accept different 24dev-* programs.  

