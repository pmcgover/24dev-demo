# 24dev-demo-0.9.5.5 Project Summary 
Welcome to the 24dev-demo-0.9.5.5 Digital Portfolio. Created on Sat Oct 22 12:17:26 UTC 2016 with the following details:
* Total number of applications: 5
* Total regression test run time in seconds: 1 
* Total regression test runs: 5  
* Number of regression test checks: 4
* Success! - All regression tests PASSED!

Regression Test Nbr|Application Name|Test Name|Run Time Seconds|Pass or Fail
 --- | --- | --- | --- | --- 
1|RScripts|HelloWorld|0|Pass
2|RScripts|top10-2014-clones-AngledXaxis|0|Pass
3|RScripts|top10-2014-clones-StraightXaxis|0|Pass
4|competitionIndexer|u07m-6yrStacks-Input|1|Pass
