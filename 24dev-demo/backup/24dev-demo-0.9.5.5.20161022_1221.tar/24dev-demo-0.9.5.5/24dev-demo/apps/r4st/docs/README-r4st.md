# r4st Plant Database 
* A plant database system featuring csv file import/export.  See details at: http://tinyurl.com/dbr4st
* Usage: Execute r4st-wraper.sh whch calls r4st-loader.sh, creates a log file and displays errors to stdout.
